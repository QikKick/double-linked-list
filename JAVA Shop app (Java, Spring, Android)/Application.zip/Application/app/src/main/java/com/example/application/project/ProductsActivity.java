package com.example.application.project;

import static com.example.application.project.helpers.Constants.DELETE_PRODUCT;
import static com.example.application.project.helpers.Constants.GET_PRODUCTS;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.application.project.helpers.Rest;
import com.example.application.project.model.Product;
import com.example.application.project.model.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ProductsActivity extends AppCompatActivity {
    User connectedUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        Button deleteBtn = findViewById(R.id.deleteBtn);  // Make sure 'deleteBtn' matches the ID in your XML
        deleteBtn.setOnClickListener(v -> {
            int productId = 11; // You need to define how to get the product ID
            deleteProduct(productId);
        });

        Intent intent = getIntent();
        String userInfo = intent.getStringExtra("userObject");
        Gson gson = new Gson();

        connectedUser = gson.fromJson(userInfo, User.class);

        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                String response = Rest.sendGet(GET_PRODUCTS);
                handler.post(() -> {
                    try {
                        if (!response.equals("Error")) {

                            Gson productsGson = new Gson();

                            Type productListType = new TypeToken<List<Product>>() {
                            }.getType();

                            List<Product> productListFromJson = productsGson.fromJson(response, productListType);

                            ListView productListElement = findViewById(R.id.productListElement);

                            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, productListFromJson);
                            productListElement.setAdapter(adapter);
                            productListElement.setOnItemClickListener((parent, view, position, id) -> {
                                System.out.println(productListFromJson.get(position));
                            });

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void deleteProduct(int productId) {
        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                String deleteUrl = DELETE_PRODUCT + productId;
                String result = Rest.sendDelete(deleteUrl);
                handler.post(() -> {
                    if (!result.startsWith("Error:")) {
                        Toast.makeText(ProductsActivity.this, "Product deleted successfully", Toast.LENGTH_SHORT).show();
                        fetchAndDisplayProducts();  // Refresh the product list
                    } else {
                        Toast.makeText(ProductsActivity.this, "Failed to delete product: " + result, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(ProductsActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }


    private void fetchAndDisplayProducts() {
        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                String response = Rest.sendGet(GET_PRODUCTS);
                handler.post(() -> {
                    try {
                        if (!response.equals("Error")) {
                            Type productListType = new TypeToken<List<Product>>() {}.getType();
                            List<Product> productList = new Gson().fromJson(response, productListType);

                            ArrayAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, productList);
                            ListView productListElement = findViewById(R.id.productListElement);
                            productListElement.setAdapter(adapter);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }



}
