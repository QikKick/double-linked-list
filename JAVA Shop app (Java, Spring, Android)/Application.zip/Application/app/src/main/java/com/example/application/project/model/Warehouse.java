package com.example.application.project.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Warehouse implements Serializable {

    private int id;
    private String title;
    private String address;

    private List<Manager> managers;

    private List<Product> inStockProducts;


    public Warehouse(String title, String address) {
        this.title = title;
        this.address = address;
        this.inStockProducts = new ArrayList<>();
        this.managers = new ArrayList<>();
    }

    @Override
    public String toString() {
        return title;
    }
}
