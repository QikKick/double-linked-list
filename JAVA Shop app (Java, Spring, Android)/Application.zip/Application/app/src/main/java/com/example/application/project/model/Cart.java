package com.example.application.project.model;


import android.os.Build;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Cart {

    private int id;
    private LocalDate dateCreated;

    private List<Product> itemsInCart;

    private User user;

    public Cart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            this.dateCreated = LocalDate.now();
        }
    }

    public Cart(Product selectedProduct) {
        this();
        this.itemsInCart = new ArrayList<>();
        this.itemsInCart.add(selectedProduct);

    }
}
