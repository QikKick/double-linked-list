package com.example.application.project.helpers;

public class Constants {
    public static final String BASE_URL = "http://10.21.21.82:8080";
    public static final String VALIDATE_USER = BASE_URL + "/user/getUserByCredentials";
    public static final String GET_PRODUCTS = BASE_URL + "/getAllProducts";
    public static final String DELETE_PRODUCT = BASE_URL + "/deleteProductById/";
}
