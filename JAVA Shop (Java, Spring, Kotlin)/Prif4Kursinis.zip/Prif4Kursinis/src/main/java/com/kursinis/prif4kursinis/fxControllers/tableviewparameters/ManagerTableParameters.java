package com.kursinis.prif4kursinis.fxControllers.tableviewparameters;

public class ManagerTableParameters extends UserTableParameters{
}
