package com.kursinis.prif4kursinis.fxControllers.tableParameters;

public class ManagerTableParameters extends UserTableParameters {
}
