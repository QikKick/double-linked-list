package com.kursinis.prif4kursinis.model;

public enum ProductType {
    FICTIONBOOK,EDUCATIONALBOOK,CHILDRENSBOOK
}
