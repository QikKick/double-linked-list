package com.example.antrasdarbas.model;

public enum ProductType {
    FICTIONBOOK,EDUCATIONALBOOK,CHILDRENSBOOK
}
