package com.example.antrasdarbas.repos;

import com.example.antrasdarbas.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WarehouseRep extends JpaRepository<Warehouse, Integer> {
}
