package com.example.antrasdarbas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AntrasDarbasApplicationTests {

    @Test
    void contextLoads() {
    }

}
