package com.example.application.project.model;


import java.time.LocalDate;

public class Comment {

    private int id;

    private String commentTitle;
    private String commentBody;
    private LocalDate dateCreated;
    private int rating;



    public Comment(Product product, String commentTitle, String commentBody, LocalDate dateCreated, int rating) {
        this.commentTitle = commentTitle;
        this.commentBody = commentBody;
        this.dateCreated = dateCreated;
        this.rating = rating;
    }
    @Override
    public String toString() {
        return  commentTitle+"; Comment: " + commentBody + "; rating: " + rating;
    }
}
