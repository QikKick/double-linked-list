package com.example.application.project.model;

public enum ProductType {
    FICTIONBOOK,EDUCATIONALBOOK,CHILDRENSBOOK
}
