package com.example.application.project;

import static com.example.application.project.helpers.Constants.VALIDATE_USER;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

//import com.R;
import com.example.application.project.helpers.Rest;
import com.example.application.project.model.Manager;
import com.example.application.project.model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void validateUser(View view) {
        TextView login = findViewById(R.id.loginField);
        TextView password = findViewById(R.id.passwordField);
        GsonBuilder build = new GsonBuilder();
        Gson gson = new Gson();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty( "login", login.getText().toString());
        jsonObject.addProperty( "password", password.getText().toString());
        String info = gson.toJson(jsonObject);

        System.out.println(info);


        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                String result = Rest.sendPost(VALIDATE_USER, info);
                System.out.println(result);
                handler.post(() -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(result);
                        String resultValue = jsonResponse.optString("result");
                        if (!result.equals("Error: 404") && !"false".equals(resultValue)) {

                            Gson userGson = new Gson();
                            User connectedUser = userGson.fromJson(result, User.class);
                            System.out.println(connectedUser.getClass());

                            if (connectedUser.getClass() == Manager.class){

                            } else{
                                Intent intent = new Intent(MainActivity.this, ProductsActivity.class);
                                intent.putExtra("userObject", result);
                                startActivity(intent);
                            }
                        } else {
                            Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }


}