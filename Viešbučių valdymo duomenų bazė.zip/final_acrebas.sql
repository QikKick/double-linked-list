/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     5/4/2023 11:33:12 PM                         */
/*==============================================================*/


alter table APMOKEJIMAS
   drop constraint FK_APMOKEJI_APMOKAMA_REZERVAC;

alter table ATLIEKAMASUZSAKYMAS
   drop constraint FK_ATLIEKAM_ATLIEKAMA_TIEKEJAS;

alter table ATLIEKAMASUZSAKYMAS
   drop constraint FK_ATLIEKAM_ATLIEKAMA_SKYRIUS;

alter table ATSILIEPIMAS
   drop constraint FK_ATSILIEP_PALIEKA_A_SVECIAS;

alter table DARBUOTOJAI
   drop constraint FK_DARBUOTO_TURI_SKYR_SKYRIUS;

alter table DARBUOTOJAI
   drop constraint FK_DARBUOTO_VYKDO_REZERVAC;

alter table INVENTORIUS
   drop constraint FK_INVENTOR_TURI_INVE_SKYRIUS;

alter table KAMBARIOPRIEZIURA
   drop constraint FK_KAMBARIO_KAMBARIOP_DARBUOTO;

alter table KAMBARIOPRIEZIURA
   drop constraint FK_KAMBARIO_KAMBARIOP_KAMBARYS;

alter table KAMBARYS
   drop constraint FK_KAMBARYS_YRA_KAMBARIO;

alter table LOJALUMO_NARYS
   drop constraint FK_LOJALUMO_PRIKLAUSO_LOJALUM2;

alter table LOJALUMO_NARYS
   drop constraint FK_LOJALUMO_TURI_STAT_SVECIAS;

alter table LOJALUMO_PREMIJA
   drop constraint FK_LOJALUMO_GAUNA_LOJALUMO;

alter table MAITINIMOPASLAUGOS
   drop constraint FK_MAITINIM_MAITINIMO_REZERVAC;

alter table MAITINIMOPASLAUGOS
   drop constraint FK_MAITINIM_MAITINIMO_MAITINIM;

alter table REZERVACIJA
   drop constraint FK_REZERVAC_ATLIEKA_SVECIAS;

alter table REZERVUOJAMAS
   drop constraint FK_REZERVUO_REZERVUOJ_REZERVAC;

alter table REZERVUOJAMAS
   drop constraint FK_REZERVUO_REZERVUOJ_KAMBARYS;

alter table VALGIARASCIO_PATIEKALAS
   drop constraint FK_VALGIARA_SUDARO_MAITINIM;

drop index APMOKAMA_FK;

drop table APMOKEJIMAS cascade constraints;

drop index ATLIEKAMASUZSAKYMAS_FK;

drop index ATLIEKAMASUZSAKYMAS2_FK;

drop table ATLIEKAMASUZSAKYMAS cascade constraints;

drop index PALIEKA_ATSILIEPIMA_FK;

drop table ATSILIEPIMAS cascade constraints;

drop index TURI_SKYRIU_FK;

drop index VYKDO_FK;

drop table DARBUOTOJAI cascade constraints;

drop index TURI_INVENTORIU2_FK;

drop table INVENTORIUS cascade constraints;

drop index KAMBARIOPRIEZIURA_FK;

drop index KAMBARIOPRIEZIURA2_FK;

drop table KAMBARIOPRIEZIURA cascade constraints;

drop table KAMBARIO_TIPAS cascade constraints;

drop index YRA_FK;

drop table KAMBARYS cascade constraints;

drop index TURI_STATUSA2_FK;

drop table LOJALUMO_NARYS cascade constraints;

drop index GAUNA_FK;

drop table LOJALUMO_PREMIJA cascade constraints;

drop table LOJALUMO_PROGRAMA cascade constraints;

drop table MAITINIMAS cascade constraints;

drop index MAITINIMOPASLAUGOS_FK;

drop index MAITINIMOPASLAUGOS2_FK;

drop table MAITINIMOPASLAUGOS cascade constraints;

drop index ATLIEKA_FK;

drop table REZERVACIJA cascade constraints;

drop index REZERVUOJAMAS_FK;

drop index REZERVUOJAMAS2_FK;

drop table REZERVUOJAMAS cascade constraints;

drop table SKYRIUS cascade constraints;

drop table SVECIAS cascade constraints;

drop table TIEKEJAS cascade constraints;

drop index SUDARO_FK;

drop table VALGIARASCIO_PATIEKALAS cascade constraints;

/*==============================================================*/
/* Table: APMOKEJIMAS                                           */
/*==============================================================*/
create table APMOKEJIMAS 
(
   APOKEJIMOID          INTEGER              not null,
   REZERVACIJOSID       INTEGER,
   KAINA                NUMBER(10,2)         not null,
   APMOKEJIMOBUDAS      VARCHAR2(20)         not null,
   APMOKEJIMODATA       DATE                 not null,
   DATA                 DATE,
   SASKAITAFAKTURA      BLOB,
   constraint PK_APMOKEJIMAS primary key (APOKEJIMOID)
);

/*==============================================================*/
/* Index: APMOKAMA_FK                                           */
/*==============================================================*/
create index APMOKAMA_FK on APMOKEJIMAS (
   REZERVACIJOSID ASC
);

/*==============================================================*/
/* Table: ATLIEKAMASUZSAKYMAS                                   */
/*==============================================================*/
create table ATLIEKAMASUZSAKYMAS 
(
   SKYRIAUSID           INTEGER              not null,
   TIEKEJOID            INTEGER              not null,
   UZSAKYMAS            CHAR(100)            not null,
   KIEKIS               INTEGER              not null,
   KAINA                NUMBER(10,2)         not null,
   PRISTATYMO_DATA      DATE,
   UZSAKYMO_DATA        DATE                 not null,
   constraint PK_ATLIEKAMASUZSAKYMAS primary key (SKYRIAUSID, TIEKEJOID)
);

/*==============================================================*/
/* Index: ATLIEKAMASUZSAKYMAS2_FK                               */
/*==============================================================*/
create index ATLIEKAMASUZSAKYMAS2_FK on ATLIEKAMASUZSAKYMAS (
   SKYRIAUSID ASC
);

/*==============================================================*/
/* Index: ATLIEKAMASUZSAKYMAS_FK                                */
/*==============================================================*/
create index ATLIEKAMASUZSAKYMAS_FK on ATLIEKAMASUZSAKYMAS (
   TIEKEJOID ASC
);

/*==============================================================*/
/* Table: ATSILIEPIMAS                                          */
/*==============================================================*/
create table ATSILIEPIMAS 
(
   ATSILIEPIMOID        INTEGER              not null,
   SVECIOID             INTEGER,
   IVERTINIMAS          INTEGER              not null,
   KOMENTARAS           CLOB,
   NUOTRAUKOS           BLOB,
   constraint PK_ATSILIEPIMAS primary key (ATSILIEPIMOID)
);

/*==============================================================*/
/* Index: PALIEKA_ATSILIEPIMA_FK                                */
/*==============================================================*/
create index PALIEKA_ATSILIEPIMA_FK on ATSILIEPIMAS (
   SVECIOID ASC
);

/*==============================================================*/
/* Table: DARBUOTOJAI                                           */
/*==============================================================*/
create table DARBUOTOJAI 
(
   DARBUOTOJOID         INTEGER              not null,
   REZERVACIJOSID       INTEGER,
   SKYRIAUSID           INTEGER,
   VARDAS               VARCHAR2(50)         not null,
   PAVARDE              VARCHAR2(50)         not null,
   PAREIGOS             VARCHAR2(50)         not null,
   ELPASTAS             VARCHAR2(100)        not null,
   TELNR                VARCHAR2(20)         not null,
   IDARBINIMODATA       DATE                 not null,
   constraint PK_DARBUOTOJAI primary key (DARBUOTOJOID)
);

/*==============================================================*/
/* Index: VYKDO_FK                                              */
/*==============================================================*/
create index VYKDO_FK on DARBUOTOJAI (
   REZERVACIJOSID ASC
);

/*==============================================================*/
/* Index: TURI_SKYRIU_FK                                        */
/*==============================================================*/
create index TURI_SKYRIU_FK on DARBUOTOJAI (
   SKYRIAUSID ASC
);

/*==============================================================*/
/* Table: INVENTORIUS                                           */
/*==============================================================*/
create table INVENTORIUS 
(
   INVENTORIAUSID       INTEGER              not null,
   SKYRIAUSID           INTEGER,
   INVENTORIAUSPAVADINIMAS CHAR(50)             not null,
   INVENTORIAUSKIEKIS   INTEGER              not null,
   INVENTORIAUSGALIOJIMOLAIKAS DATE,
   constraint PK_INVENTORIUS primary key (INVENTORIAUSID)
);

/*==============================================================*/
/* Index: TURI_INVENTORIU2_FK                                   */
/*==============================================================*/
create index TURI_INVENTORIU2_FK on INVENTORIUS (
   SKYRIAUSID ASC
);

/*==============================================================*/
/* Table: KAMBARIOPRIEZIURA                                     */
/*==============================================================*/
create table KAMBARIOPRIEZIURA 
(
   KAMBARIOID           INTEGER              not null,
   DARBUOTOJOID         INTEGER              not null,
   PRIEZIUROSTIPAS      VARCHAR2(100),
   DATA                 DATE,
   PASTEBEJIMAI         VARCHAR2(250),
   constraint PK_KAMBARIOPRIEZIURA primary key (KAMBARIOID, DARBUOTOJOID)
);

/*==============================================================*/
/* Index: KAMBARIOPRIEZIURA2_FK                                 */
/*==============================================================*/
create index KAMBARIOPRIEZIURA2_FK on KAMBARIOPRIEZIURA (
   KAMBARIOID ASC
);

/*==============================================================*/
/* Index: KAMBARIOPRIEZIURA_FK                                  */
/*==============================================================*/
create index KAMBARIOPRIEZIURA_FK on KAMBARIOPRIEZIURA (
   DARBUOTOJOID ASC
);

/*==============================================================*/
/* Table: KAMBARIO_TIPAS                                        */
/*==============================================================*/
create table KAMBARIO_TIPAS 
(
   TIPOID               INTEGER              not null,
   PAVADINIMAS          VARCHAR2(50)         not null,
   APRASYMAS            VARCHAR2(200),
   BAZINEKAINA          NUMBER(10,2)         not null,
   constraint PK_KAMBARIO_TIPAS primary key (TIPOID)
);

/*==============================================================*/
/* Table: KAMBARYS                                              */
/*==============================================================*/
create table KAMBARYS 
(
   KAMBARIOID           INTEGER              not null,
   TIPOID               INTEGER,
   KAMBARIONUMERIS      VARCHAR2(10)         not null,
   AUKSTAS              INTEGER              not null,
   MAXUZIMTAS           INTEGER              not null,
   PASKUTINISATLIKTASVALYMAS DATE                 not null,
   constraint PK_KAMBARYS primary key (KAMBARIOID)
);

/*==============================================================*/
/* Index: YRA_FK                                                */
/*==============================================================*/
create index YRA_FK on KAMBARYS (
   TIPOID ASC
);

/*==============================================================*/
/* Table: LOJALUMO_NARYS                                        */
/*==============================================================*/
create table LOJALUMO_NARYS 
(
   NARIOID              INTEGER              not null,
   SVECIOID             INTEGER,
   PROGRAMOSID          INTEGER,
   PRISIJUNGIMODATA     DATE                 not null,
   TASKUBALANSAS        INTEGER              not null,
   NARYSTESPAKOPA       VARCHAR2(50)         not null,
   REZERVUOTOSDIENOS    INTEGER              not null,
   constraint PK_LOJALUMO_NARYS primary key (NARIOID)
);

/*==============================================================*/
/* Index: TURI_STATUSA2_FK                                      */
/*==============================================================*/
create index TURI_STATUSA2_FK on LOJALUMO_NARYS (
   SVECIOID ASC
);

/*==============================================================*/
/* Table: LOJALUMO_PREMIJA                                      */
/*==============================================================*/
create table LOJALUMO_PREMIJA 
(
   PREMIJOSID           INTEGER              not null,
   NARIOID              INTEGER,
   PREMIJOSPAVADINIMAS  VARCHAR2(50)         not null,
   APRASYMAS            VARCHAR2(200),
   REIKALINGASTASKUSKAICIUS INTEGER              not null,
   GALIOJIMOLAIKAS      DATE                 not null,
   constraint PK_LOJALUMO_PREMIJA primary key (PREMIJOSID)
);

/*==============================================================*/
/* Index: GAUNA_FK                                              */
/*==============================================================*/
create index GAUNA_FK on LOJALUMO_PREMIJA (
   NARIOID ASC
);

/*==============================================================*/
/* Table: LOJALUMO_PROGRAMA                                     */
/*==============================================================*/
create table LOJALUMO_PROGRAMA 
(
   PROGRAMOSID          INTEGER              not null,
   PROGRAMOSPAVADINIMAS VARCHAR2(50)         not null,
   APRASYMAS            VARCHAR2(200),
   PAKOPA               VARCHAR2(50)         not null,
   NAUDOS               VARCHAR2(500),
   constraint PK_LOJALUMO_PROGRAMA primary key (PROGRAMOSID)
);

/*==============================================================*/
/* Table: MAITINIMAS                                            */
/*==============================================================*/
create table MAITINIMAS 
(
   MAITINIMOID          INTEGER              not null,
   MAITINIMO_PAVADINIMAS VARCHAR2(50)         not null,
   APRASAS              CLOB                 not null,
   KAINA                NUMBER(10,2)         not null,
   constraint PK_MAITINIMAS primary key (MAITINIMOID)
);

/*==============================================================*/
/* Table: MAITINIMOPASLAUGOS                                    */
/*==============================================================*/
create table MAITINIMOPASLAUGOS 
(
   MAITINIMOID          INTEGER              not null,
   REZERVACIJOSID       INTEGER              not null,
   MAITINIMU_KIEKIS     INTEGER,
   constraint PK_MAITINIMOPASLAUGOS primary key (MAITINIMOID, REZERVACIJOSID)
);

/*==============================================================*/
/* Index: MAITINIMOPASLAUGOS2_FK                                */
/*==============================================================*/
create index MAITINIMOPASLAUGOS2_FK on MAITINIMOPASLAUGOS (
   MAITINIMOID ASC
);

/*==============================================================*/
/* Index: MAITINIMOPASLAUGOS_FK                                 */
/*==============================================================*/
create index MAITINIMOPASLAUGOS_FK on MAITINIMOPASLAUGOS (
   REZERVACIJOSID ASC
);

/*==============================================================*/
/* Table: REZERVACIJA                                           */
/*==============================================================*/
create table REZERVACIJA 
(
   REZERVACIJOSID       INTEGER              not null,
   SVECIOID             INTEGER,
   REGISTRACIJOSDATA    DATE                 not null,
   SPECIALUSPRASYMAI    VARCHAR2(250),
   REZERVACIJOSBUDAS    VARCHAR2(40)         not null,
   constraint PK_REZERVACIJA primary key (REZERVACIJOSID)
);

/*==============================================================*/
/* Index: ATLIEKA_FK                                            */
/*==============================================================*/
create index ATLIEKA_FK on REZERVACIJA (
   SVECIOID ASC
);

/*==============================================================*/
/* Table: REZERVUOJAMAS                                         */
/*==============================================================*/
create table REZERVUOJAMAS 
(
   REZERVACIJOSID       INTEGER              not null,
   KAMBARIOID           INTEGER              not null,
   PRADZIOSDATA         DATE                 not null,
   PABAIGOSDATA         DATE                 not null,
   constraint PK_REZERVUOJAMAS primary key (REZERVACIJOSID, KAMBARIOID)
);

/*==============================================================*/
/* Index: REZERVUOJAMAS2_FK                                     */
/*==============================================================*/
create index REZERVUOJAMAS2_FK on REZERVUOJAMAS (
   KAMBARIOID ASC
);

/*==============================================================*/
/* Index: REZERVUOJAMAS_FK                                      */
/*==============================================================*/
create index REZERVUOJAMAS_FK on REZERVUOJAMAS (
   REZERVACIJOSID ASC
);

/*==============================================================*/
/* Table: SKYRIUS                                               */
/*==============================================================*/
create table SKYRIUS 
(
   SKYRIAUSID           INTEGER              not null,
   PAVADINIMAS          VARCHAR2(50)         not null,
   TELNR                VARCHAR2(20)         not null,
   VADOVOID             INTEGER              not null,
   constraint PK_SKYRIUS primary key (SKYRIAUSID)
);

/*==============================================================*/
/* Table: SVECIAS                                               */
/*==============================================================*/
create table SVECIAS 
(
   SVECIOID             INTEGER              not null,
   VARDAS               VARCHAR2(50)         not null,
   PAVARDE              VARCHAR2(50)         not null,
   ELPASTAS             VARCHAR2(100),
   TELNR                VARCHAR2(20)         not null,
   ADRESAS              VARCHAR2(200)        not null,
   PASOKOPIJA           BLOB                 not null,
   constraint PK_SVECIAS primary key (SVECIOID)
);

/*==============================================================*/
/* Table: TIEKEJAS                                              */
/*==============================================================*/
create table TIEKEJAS 
(
   TIEKEJOID            INTEGER              not null,
   TIEKEJOPAVADINIMAS   VARCHAR2(100)        not null,
   KONTAKTOVARDAS       VARCHAR2(100)        not null,
   ELPASTAS             VARCHAR2(100)        not null,
   TELNR                VARCHAR2(20)         not null,
   ADRESAS              VARCHAR2(200),
   constraint PK_TIEKEJAS primary key (TIEKEJOID)
);

/*==============================================================*/
/* Table: VALGIARASCIO_PATIEKALAS                               */
/*==============================================================*/
create table VALGIARASCIO_PATIEKALAS 
(
   PATIEKALOID          INTEGER              not null,
   MAITINIMOID          INTEGER,
   PATIEKALOPAVADINIMAS VARCHAR2(50)         not null,
   PATIEKALORECEPTAS    CLOB                 not null,
   ALERGENAI            VARCHAR2(250)        not null,
   VEGETARISKAS         SMALLINT,
   VEGANISKAS           SMALLINT             not null,
   constraint PK_VALGIARASCIO_PATIEKALAS primary key (PATIEKALOID)
);

/*==============================================================*/
/* Index: SUDARO_FK                                             */
/*==============================================================*/
create index SUDARO_FK on VALGIARASCIO_PATIEKALAS (
   MAITINIMOID ASC
);

alter table APMOKEJIMAS
   add constraint FK_APMOKEJI_APMOKAMA_REZERVAC foreign key (REZERVACIJOSID)
      references REZERVACIJA (REZERVACIJOSID);

alter table ATLIEKAMASUZSAKYMAS
   add constraint FK_ATLIEKAM_ATLIEKAMA_TIEKEJAS foreign key (TIEKEJOID)
      references TIEKEJAS (TIEKEJOID);

alter table ATLIEKAMASUZSAKYMAS
   add constraint FK_ATLIEKAM_ATLIEKAMA_SKYRIUS foreign key (SKYRIAUSID)
      references SKYRIUS (SKYRIAUSID);

alter table ATSILIEPIMAS
   add constraint FK_ATSILIEP_PALIEKA_A_SVECIAS foreign key (SVECIOID)
      references SVECIAS (SVECIOID);

alter table DARBUOTOJAI
   add constraint FK_DARBUOTO_TURI_SKYR_SKYRIUS foreign key (SKYRIAUSID)
      references SKYRIUS (SKYRIAUSID);

alter table DARBUOTOJAI
   add constraint FK_DARBUOTO_VYKDO_REZERVAC foreign key (REZERVACIJOSID)
      references REZERVACIJA (REZERVACIJOSID);

alter table INVENTORIUS
   add constraint FK_INVENTOR_TURI_INVE_SKYRIUS foreign key (SKYRIAUSID)
      references SKYRIUS (SKYRIAUSID);

alter table KAMBARIOPRIEZIURA
   add constraint FK_KAMBARIO_KAMBARIOP_DARBUOTO foreign key (DARBUOTOJOID)
      references DARBUOTOJAI (DARBUOTOJOID);

alter table KAMBARIOPRIEZIURA
   add constraint FK_KAMBARIO_KAMBARIOP_KAMBARYS foreign key (KAMBARIOID)
      references KAMBARYS (KAMBARIOID);

alter table KAMBARYS
   add constraint FK_KAMBARYS_YRA_KAMBARIO foreign key (TIPOID)
      references KAMBARIO_TIPAS (TIPOID);

alter table LOJALUMO_NARYS
   add constraint FK_LOJALUMO_PRIKLAUSO_LOJALUM2 foreign key (PROGRAMOSID)
      references LOJALUMO_PROGRAMA (PROGRAMOSID);

alter table LOJALUMO_NARYS
   add constraint FK_LOJALUMO_TURI_STAT_SVECIAS foreign key (SVECIOID)
      references SVECIAS (SVECIOID);

alter table LOJALUMO_PREMIJA
   add constraint FK_LOJALUMO_GAUNA_LOJALUMO foreign key (NARIOID)
      references LOJALUMO_NARYS (NARIOID);

alter table MAITINIMOPASLAUGOS
   add constraint FK_MAITINIM_MAITINIMO_REZERVAC foreign key (REZERVACIJOSID)
      references REZERVACIJA (REZERVACIJOSID);

alter table MAITINIMOPASLAUGOS
   add constraint FK_MAITINIM_MAITINIMO_MAITINIM foreign key (MAITINIMOID)
      references MAITINIMAS (MAITINIMOID);

alter table REZERVACIJA
   add constraint FK_REZERVAC_ATLIEKA_SVECIAS foreign key (SVECIOID)
      references SVECIAS (SVECIOID);

alter table REZERVUOJAMAS
   add constraint FK_REZERVUO_REZERVUOJ_REZERVAC foreign key (REZERVACIJOSID)
      references REZERVACIJA (REZERVACIJOSID);

alter table REZERVUOJAMAS
   add constraint FK_REZERVUO_REZERVUOJ_KAMBARYS foreign key (KAMBARIOID)
      references KAMBARYS (KAMBARIOID);

alter table VALGIARASCIO_PATIEKALAS
   add constraint FK_VALGIARA_SUDARO_MAITINIM foreign key (MAITINIMOID)
      references MAITINIMAS (MAITINIMOID);

